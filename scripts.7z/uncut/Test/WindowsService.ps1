#
# 20181030 Miro : Publish test service
# 20200512 Miro : Restructure/simplify variables and includes

$AutomaticVariables = Get-Variable

$scriptPath  = (Get-Item $PSScriptRoot).FullName
. "$scriptPath\CommonVariables.ps1"


$Global:ServiceName = "Background Tasks service (AssetManager)"
$Global:localFilesPath = "C:\Published\BackgroundTasksService\Uncut.Test" 
$Global:remoteFilesPath = "C:\Projects\WindowsServices\AssetManager\BackgroundTasksService\"
$Global:projectBuildFile = $branchFolder + "\BackgroundTasksService\BackgroundTasksService.csproj"
$Global:transferZipFileName = "UncutBackgoundTasksService.7z"

PublishWindowsService 
