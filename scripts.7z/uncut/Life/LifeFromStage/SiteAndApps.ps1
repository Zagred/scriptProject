# 20220308 Miro : Copied from trunk script
$Global:AngularAppPublishPath = "C:\Published\Apps\Uncut.Release\"

$scriptPath  = (Get-Item $PSScriptRoot).FullName
. "$scriptPath\Site.ps1"