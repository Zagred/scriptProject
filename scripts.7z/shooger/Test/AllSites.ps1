#
# 20181022 Miro 
# Publich "Trunk" svn branch to test.shooger.com
# Publich "Trunk" svn branch to test-media.shooger.com
# Publich "Trunk" svn branch to test-services.shooger.com
#
$LocalScriptPath  = (Get-Item $PSScriptRoot).FullName
. "$LocalScriptPath\Site.ps1"
. "$LocalScriptPath\MediaSite.ps1"
. "$LocalScriptPath\WebService.ps1"

