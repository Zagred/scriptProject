$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
#
# Everything.ps1
#
# Publish "branches/hotfixshooger" svn branch to hotfix.shooger.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
PublishSite
#
# Publich "branches/hotfixshooge" svn branch to hotfix-media.shooger.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
# pictures copy variables
$fromPictures = $branchFolder[0]+"\Shooger\ShoogerMediaAPI\"
$toPictures =  "\\$Server\c$\projects\Sites\hotfix-media.shooger.com\" 
PublishSite 
#
# 
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
$fromPictures = $branchFolder[0]+"\Shooger\ShoogerMediaAPI\"
$toPictures =  "\\$Server\c$\projects\Sites\hotfix-media.shooger.com\" 
TransferMediaSitePictures $fromPictures $toPictures
CleanupVariables
#
# Publich "branches/hotfixshooger" svn branch to hotfix.shoogerservices.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
PublishSite
