$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181030 Miro : Common variables for services.shooger.com no matter of branch
# 20200513 Miro : Restructure/simplify variables and includes
#
