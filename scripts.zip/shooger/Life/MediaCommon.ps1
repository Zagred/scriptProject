$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181030 Miro 
# 20200513 Miro : Restructure/simplify variables and includes
#
#copy to all servers
# pictures copy variables
$fromPictures = $branchFolder[0]+"\Shooger\ShoogerMediaAPI\"
$toPictures =  "\\$Server\c$\projects\Sites\media.shooger.com\" 
