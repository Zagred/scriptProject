#
# 20181022 Miro 
# Publich "Trunk" svn branch to test.shooger.com
# Publich "Trunk" svn branch to test-media.shooger.com
# Publich "Trunk" svn branch to test.shoogerservices.com
#
$LocalScriptPath  = (Get-Item $PSScriptRoot).FullName
. "$LocalScriptPath\Site.ps1"
. "$LocalScriptPath\Design.ps1"
. "$LocalScriptPath\MediaSite.ps1"
. "$LocalScriptPath\Pictures.ps1"
. "$LocalScriptPath\WebService.ps1"
. "$LocalScriptPath\WindowsService.ps1"
. "$LocalScriptPath\ScheduledTasks.ps1"

