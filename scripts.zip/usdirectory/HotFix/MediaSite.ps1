$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
#
# Publich "branches/hotfixshooger" svn branch to hotfix-media.usdirectory.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
$parentPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$parentPath\ShoogerCommonFile.ps1"
# pictures copy variables
$fromPictures = $branchFolder[0]+"\Shooger\UsdMediaSite\"
$toPictures =  "\\$Server\c$\projects\Sites\hotfix-media.usdirectory.com\" 
PublishSite 
