$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
#
# Publich "branches/hotfixshooger" svn branch to hotfix.shoogerservices.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
$parentPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$parentPath\ShoogerCommonFile.ps1"
PublishSite
