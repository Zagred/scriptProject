$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
#
# 20181022 Miro 
# Publich "Trunk" svn branch to test.usdirectory.com
# Publich "Trunk" svn branch to test-media.usdirectory.com
# Publich "Trunk" svn branch to test-services.usdirectory.com
#
# Publich "Trunk" svn branch to test.usdirectory.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
PublishSite
#
# MediaSite.ps1 : Publich "Trunk" svn branch to test-media.usdirectory.com
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
# pictures copy variables
$fromPictures = $branchFolder[0]+"\Shooger\UsdMediaSite\"
$toPictures =  "\\$Server\c$\projects\Sites\test-media.usdirectory.com\" 
PublishSite 
#
# WebService.ps1
# Publich "Trunk" svn branch to test-services.usdirectory.com
#
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
PublishSite
