#
# 20181022 Miro 
# Publich "Trunk" svn branch to test.usdirectory.com
# Publich "Trunk" svn branch to test-media.usdirectory.com
# Publich "Trunk" svn branch to test-services.usdirectory.com
#
$LocalScriptPath  = (Get-Item $PSScriptRoot).FullName
. "$LocalScriptPath\Site.ps1"
. "$LocalScriptPath\MediaSite.ps1"
. "$LocalScriptPath\WebService.ps1"

