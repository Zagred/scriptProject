$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181030 Miro 
# 20200513 Miro : Restructure/simplify variables and includes
#
# pictures copy variables
#$fromPictures = $null # $branchFolder[0]+"\Shooger\UsdMediaSite\"
#$toPictures =   $null # "\\$Server\c$\projects\Sites\media.usdirectory.com\"
