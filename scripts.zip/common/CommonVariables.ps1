$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20200511 Miro: Restructure common files
# CommonVariables.ps1
#
#
# Logging.ps1
#
function Info()
{
    param([Parameter(Mandatory=$true)][string]$message)
    Write-Host $message -ForegroundColor Yellow
}
function Error()
{
    param([Parameter(Mandatory=$true)][string]$message)
    Write-Host $message -ForegroundColor Red
}
function Warn()
{
    param([Parameter(Mandatory=$true)][string]$message)
    Write-Host $message -ForegroundColor Green
}
function SuccessFinished()
{
    param([Parameter(Mandatory=$true)][string]$message)
    Write-Host "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" -ForegroundColor Green
	Write-Host $message -ForegroundColor Green
	Write-Host "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" -ForegroundColor Green
}
function Failed()
{
	param([Parameter(Mandatory=$true)][string]$error)
	Error "???????????????????????????????????????????????????????????????????"
	Error $error
	Error "???????????????????????????????????????????????????????????????????"
	Exit 1
}
if (![bool](gv username -s global -ea ig))
{
	$Global:username = "shooger\s_transfer_user"
}
$passwordText = Get-Content "c:\Projects\p"
Remove-Variable  -Name "passwordText"
# Backup related
# Backup related
#$ngbuild = "C:\Users\miro\AppData\Roaming\npm\ng.cmd"
