$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
#
# 20200730 Miro : Restructure/simplify variables and includes
#
