$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
## 20181022 Miro : Publich "Trunk" svn branch to uncut.cloud
# 20200330 Miro : Adjust script to transfer in usd servers usdn1 and usdn2
# 20200730 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
# 20200730 Miro : Restructure/simplify variables and includes
# release from branch svn://bgsvn01:3694/Branches/20230103, Revision 6918
#
# 20200730 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
# Everything for life site
#
# 20200730 Miro : Restructure/simplify variables and includes
#
PublishSite
