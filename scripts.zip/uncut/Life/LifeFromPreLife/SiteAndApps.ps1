$Global:AngularAppPublishPath = "C:\Published\Apps\Uncut.Release\"

$scriptPath  = (Get-Item $PSScriptRoot).FullName
. "$scriptPath\Site.ps1"