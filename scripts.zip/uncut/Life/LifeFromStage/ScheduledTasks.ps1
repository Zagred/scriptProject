$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20220308 Miro : Copied from trunk script
$AutomaticVariables = Get-Variable
# 20220308 Miro : Copied from trunk script
#
# 20200730 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
# 20181030 Miro 
# 20200513 Miro : Restructure/simplify variables and includes
#
PublishProcessors
