# 20220509 Volen : Publish Uncut Apps

$Global:AngularAppPublishPath = "C:\Published\Apps\Uncut.Test\"

$scriptPath  = (Get-Item $PSScriptRoot).FullName
. "$scriptPath\Site.ps1"