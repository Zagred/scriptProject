$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# all web project have such profile, that's why it is in common file
# because that is test environment we do not need backups
$rootPath  = (Get-Item $PSScriptRoot).Parent.Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
