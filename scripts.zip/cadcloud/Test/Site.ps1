$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181022 Miro : Publich "Trunk" svn branch to test.uncut.cloud
# 20200330 :  transfer on new environment
# 20200512 Miro : Restructure/simplify variables and includes
$AutomaticVariables = Get-Variable
#
# 20200512 Miro : Restructure/simplify variables and includes
#
#
# 20200512 Miro : Restructure common variables
# Include after include particular configucation common file
#
$rootPath  = (Get-Item $PSScriptRoot).Parent.FullName
. "$rootPath\Common\CommonVariables.ps1"
. "$rootPath\Common\CommonFunctions.ps1"
. "$rootPath\Common\RemoteOperations.ps1"
# test purposes, transfer to new bgwebtest02. Remove after it is tested
PublishSite
