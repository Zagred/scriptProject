$Global:AngularAppPublishPath = "C:\Published\Apps\Cadcloud.Test"

$scriptPath  = (Get-Item $PSScriptRoot).FullName
. "$scriptPath\Site.ps1"