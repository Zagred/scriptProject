$Global:configuration = "Safeco.PreLife"
$Global:projectPublishProfile = "Safeco.PreLife.pubxml"
$Global:svnRepoPath = @("svn://bgsvn01:3695/branches/PreLife/")
$Global:branchFolder = @("D:\Projects\PreLife")
$Global:Server = "bgwebtest01.corp.shooger.com"
$Global:projectBuildFile = $branchFolder[0] + "\Shooger\ShoogerNet\ShoogerNet.csproj"
$Global:solutionBuildFile = $branchFolder[0] + "\Shooger\Shooger2017.sln"  
$Global:platform = "Any CPU"
$Global:buildCommandParams = "/p:Configuration=$configuration;Platform=`"$platform`""
$Global:localFilesPath = "c:\Published\Site\Safeco.PreLife"
$Global:remoteFilesPath = "C:\projects\sites\prelife-safeco.shooger.com\" 
$Global:transferZipFileName = "PreLifeSafeco.7z"
$Global:UpdateCss = $Global:localFilesPath + "\Web.config"
