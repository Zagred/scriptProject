$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181030 Miro 
# 20200513 Miro : Restructure/simplify variables and includes
#
# pictures copy variables
#$toPictures =   $null # "\\$Server\c$\projects\Sites\media.usdirectory.com\"$fromPictures = $branchFolder[0]+"\Shooger\ShoogerMediaAPI\"
#$toPictures =   $null # "\\$Server\c$\projects\Sites\media.usdirectory.com\"$toPictures =  "\\$Server\c$\projects\Sites\media.shooger.com\" 
