$Global:projectBuildFile = $branchFolder[0] + "\Shooger\ShoogerNet\ShoogerNet.csproj"
$Global:solutionBuildFile = $branchFolder[0] + "\Shooger\Shooger2017.sln"  
$Global:platform = "Any CPU"
$Global:buildCommandParams = "/p:Configuration=$configuration;Platform=`"$platform`""
$Global:configuration = "Safeco.Release"
$Global:projectPublishProfile = "Safeco.Release.pubxml"
$Global:Server = "usdn2.corp.shooger.com"
$Global:makeBackup = $true
$Global:BackupFolder = "C:\projects\Backup\Site\"
$Global:BackupFile =  $BackupFolder + $mydate + "_safeco.7z"
$Global:BackupPath = "C:\projects\Sites\safeco.shooger.com\*.*"
$Global:localFilesPath = "c:\Published\Site\safeco.shooger.com"
$Global:remoteFilesPath ="C:\projects\Sites\safeco.shooger.com\" 
$Global:transferZipFileName = "safeco.7z"
$Global:CopyFolder = "projects$\sites\safeco.shooger.com\"
$Global:CopyToServers = @("Webserver01.corp.shooger.com","Webserver02.corp.shooger.com","usdn1.corp.shooger.com")
$Global:UpdateCss = $Global:localFilesPath + "\Web.config"
$Global:RemoveGlimpse = $true
