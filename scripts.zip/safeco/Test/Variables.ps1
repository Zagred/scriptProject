$Global:configuration = "Safeco.Test"
$Global:projectPublishProfile = "Safeco.Test.pubxml"
$Global:svnRepoPath = @("svn://bgsvn01:3695/trunk/")
$Global:branchFolder = @("D:\Projects\trunk")
$Global:Server = "bgwebtest01.corp.shooger.com"
$Global:projectBuildFile = $branchFolder[0] + "\Shooger\ShoogerNet\ShoogerNet.csproj"
$Global:solutionBuildFile = $branchFolder[0] + "\Shooger\Shooger2017.sln"  
$Global:platform = "Any CPU"
$Global:buildCommandParams = "/p:Configuration=$configuration;Platform=`"$platform`""
$Global:localFilesPath = "c:\Published\Site\Safeco.Test"
$Global:remoteFilesPath =  "C:\projects\Sites\test-safeco.shooger.com\" 
$Global:transferZipFileName = "Safeco.7z"
