# 20200513 Miro
# General rules
# 1. Include files. Always start with include in current folder, then parent, then common folder 
#     If it is possible, include only one file 
#	  Includes are first line in file, thus parent wont overwrite variables defined in particular file
