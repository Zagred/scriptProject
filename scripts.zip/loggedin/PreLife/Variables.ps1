$Global:configuration = "Loggedin.PreLife"
$Global:projectPublishProfile = "Loggedin.PreLife.pubxml"
$Global:svnRepoPath = @("svn://bgsvn01:3695/branches/PreLife/")
$Global:branchFolder = @("D:\Projects\PreLife")
$Global:Server = "bgwebtest01.corp.shooger.com"
$Global:projectBuildFile = $branchFolder[0] + "\Shooger\ShoogerNet\ShoogerNet.csproj"
$Global:solutionBuildFile = $branchFolder[0] + "\Shooger\Shooger2017.sln"  
$Global:platform = "Any CPU"
$Global:buildCommandParams = "/p:Configuration=$configuration;Platform=`"$platform`""
$Global:localFilesPath = "c:\Published\Site\PreLife.Test"
$Global:remoteFilesPath = "C:\projects\Sites\test.loggedin.io\" 
$Global:UpdateCss = $Global:localFilesPath + "\Web.config"
$Global:transferZipFileName = "Loggedin.7z"
