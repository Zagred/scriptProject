$Global:projectBuildFile = $branchFolder[0] + "\Shooger\ShoogerNet\ShoogerNet.csproj"
$Global:solutionBuildFile = $branchFolder[0] + "\Shooger\Shooger2017.sln"  
$Global:platform = "Any CPU"
$Global:buildCommandParams = "/p:Configuration=$configuration;Platform=`"$platform`""
$Global:configuration = "Loggedin.Release"
$Global:projectPublishProfile = "Loggedin.Release.pubxml"
$Global:Server = "usdn2.corp.shooger.com"
$Global:makeBackup = $true
$Global:BackupFolder = "C:\projects\Backup\Site\"
$Global:BackupFile =  $BackupFolder + $mydate + "_Shooger.7z"
$Global:BackupPath = "C:\projects\Sites\loggedin.io\*.*"
$Global:localFilesPath = "c:\Published\Site\Loggedin.Release"
$Global:remoteFilesPath ="C:\projects\Sites\loggedin.io\" 
$Global:transferZipFileName = "loggedin.7z"
$Global:CopyFolder = "projects$\sites\loggedin.io\"
$Global:CopyToServers = @("Webserver01.corp.shooger.com","Webserver02.corp.shooger.com","usdn1.corp.shooger.com")
$Global:UpdateCss = $Global:localFilesPath + "\Web.config"
$Global:RemoveGlimpse = $true
