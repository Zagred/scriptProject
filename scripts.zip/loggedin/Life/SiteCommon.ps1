$scriptPath  = (Get-Item $PSScriptRoot).FullName 
. "$scriptPath\Variables.ps1"" 
# 20181030 Miro 
# 20200513 Miro : Restructure/simplify variables and includes
#
